import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Yard } from '../models/yard.model';

interface TrackUpdatePayload {
  timestamp?: string;
  tracks: Array<{
    trackId: number;
    distance: number;
    siren: number;
    timestamp?: string;
    lastUpdated?: number;
  }>;
}

@Injectable({
  providedIn: 'root',
})
export class YardApiService {
  private readonly websocketUrl = 'ws://localhost:1880/ws/tracks';
  private socket: WebSocket | null = null;
  private readonly yardSubject = new BehaviorSubject<Yard>(this.createInitialYard());

  getYard(): Observable<Yard> {
    return of(this.yardSubject.getValue());
  }

  connect(): Observable<Yard> {
    if (!this.socket) {
      this.socket = new WebSocket(this.websocketUrl);

      this.socket.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          const payload = msg.payload as TrackUpdatePayload;
          const nextYard = this.applyTrackUpdates(payload, this.yardSubject.getValue());
          this.yardSubject.next(nextYard);
        } catch (error) {
          console.error('Failed to parse track websocket payload', error);
        }
      };

      this.socket.onerror = (event) => {
        console.error('Track websocket error', event);
      };
    }

    return this.yardSubject.asObservable();
  }

  disconnect(): void {
    this.socket?.close();
    this.socket = null;
  }

  applyTrackUpdates(payload: TrackUpdatePayload, baseYard: Yard): Yard {
    const trackMap = new Map(baseYard.tracks.map((track) => [track.id, track]));

    payload.tracks.forEach((update) => {
      const existingTrack = trackMap.get(update.trackId);
      const nextPosition = Math.min(existingTrack?.length ?? 100, Math.max(0, update.distance));
      const status = update.siren === 1 ? 'STOPPED' : 'MOVING';

      if (existingTrack) {
        trackMap.set(update.trackId, {
          ...existingTrack,
          train: {
            ...existingTrack.train,
            position: nextPosition,
            status: status as 'STOPPED' | 'MOVING',
          },
        });
        return;
      }

      trackMap.set(update.trackId, {
        id: update.trackId,
        name: `Track-${update.trackId}`,
        length: 100,
        train: {
          locoId: `Loco-${update.trackId}`,
          position: nextPosition,
          speed: 0,
          direction: 'RIGHT',
          status: status as 'STOPPED' | 'MOVING',
        },
        redZone: {
          start: 70,
          end: 100,
        },
        sensors: [],
      });
    });

    return {
      ...baseYard,
      lastUpdated: payload.timestamp ?? new Date().toISOString(),
      tracks: Array.from(trackMap.values()),
    };
  }

  private createInitialYard(): Yard {
    return {
      stationName: '',
      lastUpdated: '',
      tracks: [],
    };
  }
}
