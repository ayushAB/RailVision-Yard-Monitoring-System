import { Component, computed, effect, input, OnDestroy, OnInit, signal } from '@angular/core';

import { Track } from '../../../core/models/track.model';
import { Train } from '../train/train';

@Component({
  selector: 'app-track-renderer',
  standalone: true,
  imports: [Train],
  templateUrl: './track-renderer.html',
  styleUrl: './track-renderer.css',
})
export class TrackRenderer implements OnInit, OnDestroy {
  track = input.required<Track>();

  /**
   * Animated position displayed on screen
   */
  currentPosition = signal(0);

  /**
   * Latest backend position
   */
  targetPosition = signal(0);

  private animationId?: number;

  /**
   * Time of previous animation frame
   */
  private lastFrameTime = 0;

  /**
   * Time when last websocket update arrived
   */
  private lastPacketTime = performance.now();

  /**
   * Estimated speed (meters/sec)
   */
  private speed = 0;

  constructor() {
    effect(() => {
      const train = this.track().train;

      if (!train) {
        return;
      }

      const newPosition = Number(train.position);

      if (!Number.isFinite(newPosition)) {
        return;
      }

      const now = performance.now();

      const previousTarget = this.targetPosition();

      const elapsed = (now - this.lastPacketTime) / 1000;

      if (elapsed > 0.05) {
        this.speed = Math.abs(newPosition - previousTarget) / elapsed;
      }

      this.lastPacketTime = now;

      this.targetPosition.set(newPosition);

      console.log(
        `Track ${this.track().id}`,
        `Target=${newPosition}`,
        `Speed=${this.speed.toFixed(2)} m/s`,
      );
    });
  }

  ngOnInit(): void {
    const start = Number(this.track().train.position);

    this.currentPosition.set(Number.isFinite(start) ? start : 0);
    this.targetPosition.set(Number.isFinite(start) ? start : 0);

    this.animationId = requestAnimationFrame(this.animate);
  }

  ngOnDestroy(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
  }

  /**
   * Runs at ~60 FPS
   */
  private animate = (time: number) => {
    if (!this.lastFrameTime) {
      this.lastFrameTime = time;
    }

    const deltaSeconds = (time - this.lastFrameTime) / 1000;

    this.lastFrameTime = time;

    let current = this.currentPosition();
    const target = this.targetPosition();

    if (!Number.isFinite(current) || !Number.isFinite(target)) {
      this.animationId = requestAnimationFrame(this.animate);
      return;
    }

    if (Math.abs(target - current) < 0.02) {
      current = target;
    } else {
      const direction = Math.sign(target - current);

      const movement = this.speed * deltaSeconds;

      current += movement * direction;

      if ((direction > 0 && current > target) || (direction < 0 && current < target)) {
        current = target;
      }
    }

    this.currentPosition.set(current);

    this.animationId = requestAnimationFrame(this.animate);
  };

  /**
   * Convert meters to SVG coordinate
   */
  trainX = computed(() => {
    const svgStart = 40;
    const svgWidth = 1120;

    let pos = this.currentPosition();

    if (!Number.isFinite(pos)) {
      pos = 0;
    }

    pos = Math.max(0, Math.min(pos, this.track().length));

    return svgStart + (pos / this.track().length) * svgWidth;
  });

  sensors = computed(() => this.track().sensors);

  sleepers = Array.from({ length: 45 }, (_, i) => i);

  scale = Array.from({ length: 11 }, (_, i) => i);

  sensorX(position: number) {
    return 40 + (position / this.track().length) * 1120;
  }
}
